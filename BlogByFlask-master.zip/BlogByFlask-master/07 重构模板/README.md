# 重构模板

你可以查看这篇文章获取更加详细的内容：
- [Flask 搭建个人博客教程 7 —— 重构模板](https://www.hizxc.com/1772.html)