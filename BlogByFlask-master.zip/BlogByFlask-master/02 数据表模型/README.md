# BlogByFlask 数据表模型

你可以查看这篇文章获取更加详细的内容：
- [Flask 搭建个人博客教程 2 —— 数据表模型](https://www.hizxc.com/1723.html)
