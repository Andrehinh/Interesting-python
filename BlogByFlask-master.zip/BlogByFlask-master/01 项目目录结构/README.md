# BlogByFlask 项目目录结构

你可以查看这篇文章获取更加详细的内容：
- [Flask 搭建个人博客教程 1 —— 前言及项目目录](https://www.hizxc.com/1716.html)
