from app.models.post import Post
from app.models.category import Category
from app.models.middle_table import post_category_middle
from app.models.comment import Comment
from app.models.admin import Admin
from app.models.link import Link
